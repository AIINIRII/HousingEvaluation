INSERT INTO housing_evaluation.house_type (type_id, type_name) VALUES (0, '板楼');
INSERT INTO housing_evaluation.house_type (type_id, type_name) VALUES (1, '塔楼');
INSERT INTO housing_evaluation.house_type (type_id, type_name) VALUES (2, '板塔结合');
INSERT INTO housing_evaluation.house_type (type_id, type_name) VALUES (3, '平房');