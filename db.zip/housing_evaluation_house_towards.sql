INSERT INTO housing_evaluation.house_towards (towards_id, towards_name) VALUES (0, '南');
INSERT INTO housing_evaluation.house_towards (towards_id, towards_name) VALUES (1, '北');
INSERT INTO housing_evaluation.house_towards (towards_id, towards_name) VALUES (2, '东');
INSERT INTO housing_evaluation.house_towards (towards_id, towards_name) VALUES (3, '西');
INSERT INTO housing_evaluation.house_towards (towards_id, towards_name) VALUES (4, '西南');
INSERT INTO housing_evaluation.house_towards (towards_id, towards_name) VALUES (5, '东南');
INSERT INTO housing_evaluation.house_towards (towards_id, towards_name) VALUES (6, '东北');
INSERT INTO housing_evaluation.house_towards (towards_id, towards_name) VALUES (7, '西北');